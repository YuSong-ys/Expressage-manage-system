<template>
  <div>
    page1
  </div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped></style>
